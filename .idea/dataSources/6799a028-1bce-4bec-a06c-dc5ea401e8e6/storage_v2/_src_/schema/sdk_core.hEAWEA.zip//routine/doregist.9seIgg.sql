create procedure doRegist(IN name      varchar(55), IN NUM varchar(11), IN password varchar(32),
                          IN nickname  varchar(50), IN channelId int, IN userType int, IN gameId int, OUT id int)
  BEGIN
  DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; 
  START TRANSACTION; 
		insert into USER(NAME,NUM,PASSWORD,NICKNAME,CHANNEL_ID,REGIST_DATE, USER_TYPE) 
    values (name,num,password,nickname,channelId,now(), userType);
		set id=@@identity;
		insert into USER_NAME(NAME,USER_ID) values (name,id);
		insert into USER_DYNAMIC(USER_ID) values(id);
    insert into sdk_log.GAME_REGIST_LOG (USER_ID, GAME_ID, PROMOTION_CHANNEL_ID, CREATED_DATE) values 
    (id, gameId, channelId, now());
	IF t_error = 1 THEN 
		ROLLBACK;  
		SET id=0;
  ELSE  
    COMMIT;  
  END IF; 
END;

